<?php 
        
    require('getservices.php');
    session_start();
    $id = $_SESSION['id'];
    $firstname = $_SESSION['name'];
    if (isset($_SESSION['id'])){

    } else{
        header("Location:login.php");
    }
    
    

 ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Services - Front End, Back End Demo</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,400i,700,700i,600,600i">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.css">
    <link rel="stylesheet" href="assets/css/smoothproducts.css">
</head>

<body>
    <nav class="navbar navbar-light navbar-expand-lg fixed-top bg-white clean-navbar">
        <div class="container"><img src="logo_75df62bfb3d75ba6978524d3f4e71428_1x.png" style="padding-right: 17px;width: 90px;" /><a class="navbar-brand logo" href="#">Front End, Back End Demo</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
            <div
                class="collapse navbar-collapse" id="navcol-1">
                <ul class="nav navbar-nav ml-auto">
                    <li class="nav-item" role="presentation"><a class="nav-link" href="index.html">Home</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link active">Services</a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link active"><?php echo($firstname) ?></a></li>
                    <li class="nav-item" role="presentation"><a class="nav-link" href="Logout.php">Logout</a></li>
                </ul>
        </div>
        </div>
    </nav>
    <main class="page service-page">
        <section class="clean-block clean-services dark">
            <div class="container">
                <div class="block-heading">
                    <h2 class="text-info">Service Page</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam urna, dignissim nec auctor in, mattis vitae leo.</p>
                </div>
                <div class="row">

                            <?php foreach(getService() as $data){?>


                                            <div class="col-md-6 col-lg-4">
                                            <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/scenery/image5.jpg">
                                            <div class="card-body">
                                            <h4 class="card-title"><?php echo $data["1"];?></h4>
                                            <p class="card-text"><?php echo $data["2"];?></p>
                                            </div>
                                            <div><button class="btn btn-outline-primary btn-sm" type="button">Learn More</button></div>
                                            </div>
                                            </div>
                                            
                                             <?php }?>
                   
                    <div class="col-md-6 col-lg-4">
                        <div class="card"><img class="card-img-top w-100 d-block" src="assets/img/scenery/image5.jpg">
                            <div class="card-body">
                                <h4 class="card-title">Lorem Ipsum</h4>
                                <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc quam urna, dignissim nec auctor in.</p>
                            </div>
                            <div><button class="btn btn-outline-primary btn-sm" type="button">Learn More</button></div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </section>
    </main>
    <footer class="page-footer dark">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <h5>Get started</h5>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Sign up</a></li>
                        <li><a href="#">Downloads</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>About us</h5>
                    <ul>
                        <li><a href="#">Company Information</a></li>
                        <li><a href="#">Contact us</a></li>
                        <li><a href="#">Reviews</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>Support</h5>
                    <ul>
                        <li><a href="#">FAQ</a></li>
                        <li><a href="#">Help desk</a></li>
                        <li><a href="#">Forums</a></li>
                    </ul>
                </div>
                <div class="col-sm-3">
                    <h5>Legal</h5>
                    <ul>
                        <li><a href="#">Terms of Service</a></li>
                        <li><a href="#">Terms of Use</a></li>
                        <li><a href="#">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright">
            <p>© Nicodemie Delgado.</p>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/baguettebox.js/1.10.0/baguetteBox.min.js"></script>
    <script src="assets/js/smoothproducts.min.js"></script>
    <script src="assets/js/theme.js"></script>
    <script type="text/javascript">

        $("#errormessage").hide();
        $("#successmessage").hide();
        $("#infomessage").hide();

        
            $.ajax({
                url: 'getservices.php',
                type: "POST",
                data: {
                                    
                },
                cache: false,
                success: function(dataResult){
                    var dataResult = JSON.parse(dataResult);
                    JSON.stringify(dataResult);
                    console.log(dataResult);
                }
            });

    </script>
</body>

</html>